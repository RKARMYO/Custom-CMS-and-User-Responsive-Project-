$('document').ready(function(){
		
        
});
	
       