<?php
	header("Access-Control-Allow-Origin:*");
	if(isset($_POST['username']))
	{
		if($_POST['username']=='yangonrescue' && $_POST['password']=='mmsoftware10055')
		{
			//echo true;
			$data=array("status"=>"101","code"=>"16541105621");
			echo json_encode($data);
		}
		else
		{
			echo false;
		}
	}
?>